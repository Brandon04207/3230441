export class UI {
  constructor() {
    this.initializeElements();
  }

  initializeElements() {
    // Cache de elementos DOM
    this.elements = {
      productsTableBody: document.getElementById('productsTableBody'),
      productModal: document.getElementById('productModal'),
      deleteModal: document.getElementById('deleteModal'),
      productForm: document.getElementById('productForm'),
      searchInput: document.getElementById('searchInput'),
      btnSearch: document.getElementById('btnSearch'),
      loadingIndicator: document.getElementById('loadingIndicator'),
      successAlert: document.getElementById('successAlert'),
      errorAlert: document.getElementById('errorAlert'),
      productsTableContainer: document.getElementById('productsTableContainer')
    };
  }

  // ... métodos para manejar la UI (renderProducts, showLoading, etc.)
}