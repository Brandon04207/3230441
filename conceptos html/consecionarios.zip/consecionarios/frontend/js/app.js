import { ProductosAPI } from './api/productosAPI.js';
import { UI } from './ui/ui.js';

class App {
  constructor() {
    this.ui = new UI();
    this.products = [];
    this.init();
  }

  async init() {
    this.setupEventListeners();
    await this.loadProducts();
  }

  setupEventListeners() {
    // Configurar todos los event listeners
    this.ui.setAddProductListener(() => this.openModal());
    this.ui.setSearchListener((query) => this.searchProducts(query));
    this.ui.setFormSubmitListener((productData) => this.saveProduct(productData));
    this.ui.setDeleteListener((id) => this.deleteProduct(id));
  }

  async loadProducts() {
    try {
      this.ui.showLoading(true);
      this.products = await ProductosAPI.getAll();
      this.ui.renderProducts(this.products);
    } catch (error) {
      this.ui.showError(error.message);
    } finally {
      this.ui.showLoading(false);
    }
  }

  async searchProducts(query) {
    try {
      if (!query.trim()) {
        this.ui.renderProducts(this.products);
        return;
      }
      
      const filteredProducts = await ProductosAPI.search(query);
      this.ui.renderProducts(filteredProducts);
    } catch (error) {
      this.ui.showError(error.message);
    }
  }

  async saveProduct(productData) {
    try {
      if (productData.id) {
        await ProductosAPI.update(productData.id, productData);
        this.ui.showSuccess('Producto actualizado correctamente');
      } else {
        await ProductosAPI.create(productData);
        this.ui.showSuccess('Producto creado correctamente');
      }
      
      this.ui.closeModal();
      await this.loadProducts();
    } catch (error) {
      this.ui.showError(error.message);
    }
  }

  async deleteProduct(id) {
    try {
      await ProductosAPI.delete(id);
      this.ui.showSuccess('Producto eliminado correctamente');
      this.ui.closeDeleteModal();
      await this.loadProducts();
    } catch (error) {
      this.ui.showError(error.message);
    }
  }

  openModal(product = null) {
    this.ui.openModal(product);
  }
}

// Inicializar la aplicación cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
  new App();
});